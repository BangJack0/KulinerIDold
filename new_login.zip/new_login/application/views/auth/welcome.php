<!DOCTYPE html>
<html>
<head>
    <title>Halaman Welcome</title>
    <style>
        @import url(https://fonts.googleapis.com/css?family=Roboto:300);

        body {
            font-family: "Roboto", sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            background-color: #3F2305;
            background-image: linear-gradient(180deg, #f5f5f5 10%, #3F2305 100%);
            background-repeat: no-repeat;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            text-align: center;
        }

        h1, p, h3 {
            color: black;
            margin: 0;
        }

        p1 {
            color: #4169E1;
            font-size: 18px;
        }
    </style>
</head>
<body>
<div class="container">
        <center> <h1>WELCOME</h1>
        <h3 align="center">Selamat Datang Di Menu Admin<br>
        <br>
        Klik <a href="logout.php"><p1>disini</p1></a> untuk logout <p> </pre>
    <p align=center> Berikut ini adalah menu navigasi anda</p>
    <h4 align=center><a href='halamankomik.php'> <p1>Halaman Komik</a> ||
        <a href='halamanuser.php'> <p1>Halaman User </a>
</div>
</body>
</html>
